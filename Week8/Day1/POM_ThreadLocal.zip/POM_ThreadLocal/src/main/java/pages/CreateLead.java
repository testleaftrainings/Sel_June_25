package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class CreateLead extends BaseClass {
	
@When("Enter the company name as(.*)$")
public CreateLead entercName(String cName) {
	getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
	return this;
	
}
@And("enter the first name as(.*)$")
public CreateLead enterfName(String fName) {
	getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
	return this;
	
}
@And("Enter the last name as(.*)$")
public CreateLead enterlName(String lName) {
	getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
	return this;
	
}
@When("click on the leads button")
public ViewLeads clickSubmit() {
	getDriver().findElement(By.name("submitButton")).click();
	return new ViewLeads();
	
}
}
