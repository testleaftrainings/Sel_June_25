package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.login;

public class RunCreateLead extends BaseClass {
	@BeforeTest
	public void setValues() {
		excelFileName="CreateLead";
		
	}
	@Test(dataProvider="fetchData")
	public void runCreateLead(String uName,String pwd,String cName,String fName,String lName) {
		
		login l=new login(driver);
		l.enterUname(uName).enterPwd(pwd).clickLogin().clickCrmsfa().clickLeads().createLead().entercName(cName)
		.enterfName(fName).enterlName(lName).clickSubmit().verifyLeads();
		
	}

}
