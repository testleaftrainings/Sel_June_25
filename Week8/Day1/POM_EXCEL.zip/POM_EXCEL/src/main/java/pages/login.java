package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;

public class login extends BaseClass{
	
	public login(EdgeDriver driver) {
		this.driver=driver;
		
	}
	
	public login enterUname(String uName) {
		driver.findElement(By.id("username")).sendKeys(uName);
		/*
		 * login lp=new login(); return lp;
		 */
		return this;
		
		
	}
	public login enterPwd(String pwd) {
		driver.findElement(By.id("password")).sendKeys(pwd);
		return this;
		
	}
	public WelcomePage clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage(driver);
		
	}

}
