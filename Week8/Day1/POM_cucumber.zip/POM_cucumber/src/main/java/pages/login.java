package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class login extends BaseClass{
	
	
	@When("Enter the username as {string}")
	public login enterUname(String uName) {
		driver.findElement(By.id("username")).sendKeys(uName);
		/*
		 * login lp=new login(); return lp;
		 */
		return this;
		
		
	}
	@When("Enter the password as {string}")
	public login enterPwd(String pwd) {
		driver.findElement(By.id("password")).sendKeys(pwd);
		return this;
		
	}
	@And("Click on the login button")
	public WelcomePage clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage();
		
	}

}
