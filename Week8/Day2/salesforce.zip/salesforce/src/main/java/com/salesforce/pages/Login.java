package com.salesforce.pages;

import org.openqa.selenium.WebElement;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class Login extends ProjectSpecificMethods{
	
	public Login entereUname(String uName) {
		
		WebElement eleUname = locateElement("username");
		type(eleUname, uName);
		reportStep("uname entered succesfully",uName,true);
		return this;
	}
	public Login enterPwd(String pwd) {
		
		/*
		 * WebElement elePwd = locateElement("password"); type(elePwd, pwd);
		 */
		
		WebElement elePwd = locateElement(Locators.XPATH, "//input[@id='password']");
		type(elePwd, pwd);
		return this;
	}
	public HomePage clickLogin() {
		click(locateElement("Login"));
		return new HomePage();
	}

}
