package com.salesforce.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.salesforce.pages.Login;

public class VerifyLogin extends ProjectSpecificMethods{
	@BeforeTest
	public void setValues() {
		 excelFileName="login";
		testcaseName="Login";
		testDescription="login with positive credentials";
		
		authors="vidhya";
		category="smoke";
		
		
	}
	@Test(dataProvider="fetchData")
	public void runLogin(String uName,String pwd) {
		Login l=new Login();
		l.entereUname(uName).enterPwd(pwd).clickLogin();
		
	}

}
